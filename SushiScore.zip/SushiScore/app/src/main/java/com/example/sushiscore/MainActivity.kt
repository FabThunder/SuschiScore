package com.example.sushiscore

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    private var score = 0
    private var highscore = 0
    private var timerSeconds = 0
    private var timerRunning = false
    private val timerHandler = Handler(Looper.getMainLooper())

    private lateinit var tvScore: TextView
    private lateinit var tvHighscore: TextView
    private lateinit var tvTimer: TextView
    private lateinit var ivNigiri: ImageView

    private val timerRunnable = object : Runnable {
        override fun run() {
            timerSeconds++
            updateTimerDisplay()
            timerHandler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvScore     = findViewById(R.id.tvScore)
        tvHighscore = findViewById(R.id.tvHighscore)
        tvTimer     = findViewById(R.id.tvTimer)
        ivNigiri    = findViewById(R.id.ivNigiri)

        // tap sul nigiri o ovunque
        findViewById<View>(R.id.rootLayout).setOnClickListener { addPiece() }

        // timer avvia/pausa
        tvTimer.setOnClickListener { toggleTimer() }

        // reset
        findViewById<ImageButton>(R.id.btnReset).setOnClickListener { reset() }
    }

    private fun addPiece() {
        if (!timerRunning) return
        score++
        if (score > highscore) highscore = score
        tvScore.text = score.toString()
        tvHighscore.text = "YOUR HIGHSCORE IS $highscore"
        animateNigiri()
    }

    private fun animateNigiri() {
        val randomRotation = (-12 + (-12..12).random()).toFloat()
        ivNigiri.animate()
            .rotation(randomRotation)
            .scaleX(1.1f)
            .scaleY(1.1f)
            .setDuration(100)
            .withEndAction {
                ivNigiri.animate()
                    .scaleX(1f)
                    .scaleY(1f)
                    .setDuration(100)
                    .start()
            }.start()
    }

    private fun toggleTimer() {
        if (!timerRunning) {
            timerRunning = true
            timerHandler.postDelayed(timerRunnable, 1000)
        } else {
            timerRunning = false
            timerHandler.removeCallbacks(timerRunnable)
        }
        updateTimerDisplay()
    }

    private fun updateTimerDisplay() {
        val m = timerSeconds / 60
        val s = timerSeconds % 60
        val icon = if (timerRunning) "⏸" else "▶"
        tvTimer.text = "$icon %02d:%02d".format(m, s)
    }

    private fun reset() {
        score = 0
        timerSeconds = 0
        timerRunning = false
        timerHandler.removeCallbacks(timerRunnable)
        tvScore.text = "0"
        tvHighscore.text = "YOUR HIGHSCORE IS $highscore"
        tvTimer.text = "▶ 00:00"
        ivNigiri.rotation = -12f
    }

    override fun onDestroy() {
        super.onDestroy()
        timerHandler.removeCallbacks(timerRunnable)
    }
}